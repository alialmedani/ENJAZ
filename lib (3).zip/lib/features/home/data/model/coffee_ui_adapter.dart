// // lib/features/home/data/model/coffee_ui_adapter.dart
// import 'coffee_api_model.dart';
// import 'old/coffee_model.dart';

// extension CoffeeUiAdapter on CoffeeApiModel {
//   Coffee toUi() => Coffee(
//     image: 'assets/images/coffee1.png', // fallback محلي
//     name: name,
//     type: 'Popular',
//     rate: 4.8,
//     review: 0,
//     description: description,
//     price: 4.99,
//   );
// }
