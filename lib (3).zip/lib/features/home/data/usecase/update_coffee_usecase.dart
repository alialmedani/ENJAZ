// import 'package:enjaz/core/results/result.dart';
// import 'package:enjaz/core/usecase/usecase.dart';
// import 'package:enjaz/features/home/data/repo/coffee_repository.dart';
// import 'package:enjaz/features/home/data/usecase/coffee_api_params.dart';
// import '../model/coffee_api_model.dart';
  
// class UpdateCoffeeUseCase extends UseCase<CoffeeApiModel, UpdateCoffeeParams> {
//   final CoffeeRepository repo;
//   UpdateCoffeeUseCase(this.repo);

//   @override
//   Future<Result<CoffeeApiModel>> call({required UpdateCoffeeParams params}) {
//     return repo.updateCoffee(params: params);
//   }
// }
