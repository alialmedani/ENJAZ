import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/core/repository/core_repository.dart';
import 'package:enjaz/core/http/http_method.dart';
import 'package:enjaz/core/data_source/remote_data_source.dart';
import 'package:enjaz/core/constant/end_points/api_url.dart';
import 'package:enjaz/features/order/data/model/order_model.dart';
import 'package:enjaz/features/order/data/uscase/create_drink_order_lite_usecase.dart';
import '../uscase/create_drink_order_usecase.dart';

class OrderRepository extends CoreRepository {


    Future<Result<OrderModel>> createDrinkOrder({
    required CreateDrinkOrderParams params,
  }) async {
    final result = await RemoteDataSource.request<OrderModel>(
      withAuthentication: true,
      url: createDrinkOrderUrl,
      method: HttpMethod.POST,
      data: params.toJson(),
      converter: (json) => OrderModel.fromJson(json),
    );
    return call(result: result);
  }

  // 👇 النسخة الخفيفة: بدون floor/office
  Future<Result<OrderModel>> createDrinkOrderLite({
    required CreateDrinkOrderLiteParams params,
  }) async {
    final result = await RemoteDataSource.request<OrderModel>(
      withAuthentication: true,
      url: createDrinkOrderUrl,
      method: HttpMethod.POST,
      data: params.toJson(), // { orderItems: [...] }
      converter: (json) => OrderModel.fromJson(json),
    );
    return call(result: result);
  }
 
  Future<Result<List<OrderModel>>> getOrders() async {
    final result = await RemoteDataSource.request<List<OrderModel>>(
      withAuthentication: true,
      url: getOrdersUrl,
      method: HttpMethod.GET,
      converter2: (json) {
        final list = (json is List)
            ? json
            : (json['items'] as List?) ?? (json['data'] as List?) ?? const [];
        return list
            .whereType<Map>() // أمان
            .map((e) => OrderModel.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      },
    );
    return call(result: result);
  }
}
