import 'package:enjaz/core/params/base_params.dart';
import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/core/usecase/usecase.dart';
import 'package:enjaz/features/order/data/model/order_model.dart';
import 'package:enjaz/features/order/data/repository/order_repository.dart';
import 'create_order_item_usecase.dart';

class CreateDrinkOrderLiteParams extends BaseParams {
  final List<CreateOrderItemParams> orderItems;
  CreateDrinkOrderLiteParams({required this.orderItems});

  Map<String, dynamic> toJson() => {
    "orderItems": orderItems.map((e) => e.toJson()).toList(),
  };
}

class CreateDrinkOrderLiteUseCase
    extends UseCase<OrderModel, CreateDrinkOrderLiteParams> {
  final OrderRepository repository;
  CreateDrinkOrderLiteUseCase(this.repository);

  @override
  Future<Result<OrderModel>> call({required CreateDrinkOrderLiteParams params}) {
    return repository.createDrinkOrderLite(params: params);
  }
}
