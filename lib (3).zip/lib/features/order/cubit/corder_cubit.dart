// lib/features/order/cubit/order_cubit.dart
import 'package:enjaz/features/order/data/model/order_model.dart';
import 'package:enjaz/features/order/data/uscase/create_drink_order_lite_usecase.dart';
 import 'package:enjaz/features/order/data/uscase/create_drink_order_usecase.dart';
import 'package:enjaz/features/order/data/uscase/create_order_item_usecase.dart';
import 'package:enjaz/features/order/data/uscase/get_orders_usecase.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/features/order/data/repository/order_repository.dart';
// انتبه لمسار المجلد: usecase وليس uscase إذا كنت كاتبه صح

class OrderCubit extends Cubit<void> {
  OrderCubit() : super(null);

  final OrderRepository _repo = OrderRepository();
  late final GetOrdersUseCase _getOrdersUC = GetOrdersUseCase(_repo);

  CreateDrinkOrderParams createDrinkOrderParams = CreateDrinkOrderParams(
    floor: 0,
    office: "",
    orderItems: <CreateOrderItemParams>[],
  );
  CreateOrderItemParams createOrderItemParams = CreateOrderItemParams(
    drinkId: "",
    sugarLevel: 0,
    quantity: 0,
    notes: "",
  );
  Future<Result<OrderModel>> addDrinkToCart({
    required String drinkId,
    required int floor,
    required String office,
    int sugarLevel = 0,
    int quantity = 1,
    String notes = '',
  }) async {
    createDrinkOrderParams = CreateDrinkOrderParams(
      floor: floor,
      office: office,
      orderItems: [
        CreateOrderItemParams(
          drinkId: drinkId,
          sugarLevel: sugarLevel,
          quantity: quantity,
          notes: notes,
        ),
      ],
    );
    return await CreateDrinkOrderUseCase(
      _repo,
    ).call(params: createDrinkOrderParams);
  }

  Future<Result> createOrder() async {
    return await CreateDrinkOrderUseCase(
      OrderRepository(),
    ).call(params: createDrinkOrderParams);
  }

  Future<Result<List<OrderModel>>> getOrders() {
    return _getOrdersUC();
  }


   Future<Result<OrderModel>> addItemToOrder({
    required String drinkId,
    required int quantity,
    int sugarLevel = 0,
    String notes = '',
  }) async {
    final item = CreateOrderItemParams(
      drinkId: drinkId,
      sugarLevel: sugarLevel,
      quantity: quantity,
      notes: notes,
    );

    final params = CreateDrinkOrderLiteParams(orderItems: [item]);
    return await CreateDrinkOrderLiteUseCase(_repo).call(params: params);
  }
}
