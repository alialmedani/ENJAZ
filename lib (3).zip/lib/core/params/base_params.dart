abstract class BaseParams {
  BaseParams();
}
