// import 'package:jedar_center/features/matrix/data/model/matrix.dart';

// String getTabContent(MatrixModel product, int tabIndex) {
//   switch (tabIndex) {
//     case 0:
//       return product.parsedDescription['description'] ?? "N/A";
//     case 1:
//       return product.parsedDescription['usage'] ?? "N/A";
//     case 2:
//       return product.parsedDescription['component'] ?? "N/A";
//     default:
//       return "N/A";
//   }
// }
