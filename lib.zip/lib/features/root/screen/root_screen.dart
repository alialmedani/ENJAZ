import 'package:enjaz/features/auth/screen/login_screen.dart';
import 'package:enjaz/features/auth/screen/login1_screen.dart';
import 'package:enjaz/features/home/screen/home_screen.dart';
import 'package:enjaz/features/order/orders_screen.dart';
 import 'package:enjaz/features/profile/screen/profile_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import '../../../core/constant/app_colors/app_colors.dart';
import '../../../generated/l10n.dart';

import '../cubit/root_cubit.dart';

class RootScreen extends StatelessWidget {
  const RootScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<RootCubit, RootState>(
      builder: (context, state) {
        int currentIndex = context.read<RootCubit>().rootIndex;

        return Scaffold(
          bottomNavigationBar: SafeArea(
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.xbackgroundColor,
                boxShadow: [
                  BoxShadow(
                    blurRadius: 20,
                    color: Colors.black.withOpacity(0.1),
                  ),
                ],
              ),
              padding: EdgeInsets.symmetric(horizontal: 28.w, vertical: 2.h),
              child: GNav(
                gap: 2,
                color: AppColors.xsecondaryColor,
                activeColor: AppColors.xprimaryColor,
                iconSize: 14,
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 15.h),
                tabBackgroundColor: AppColors.secondPrimery.withOpacity(0.2),
                backgroundColor: AppColors.xbackgroundColor,
                selectedIndex: currentIndex,
                onTabChange: (index) {
                  context.read<RootCubit>().changePageIndex(index);
                },
                tabs: [
                  GButton(icon: Icons.home, text: S.of(context).Home),
                   GButton(icon: Icons.local_offer, text: S.of(context).Orders),
                  GButton(icon: Icons.person_2_outlined, text: S.of(context).profile),
                  // GButton(
                  //   icon: Icons.shopping_cart,
                  //   text: S.of(context).My_Cart,
                  // ),
                  // GButton(
                  //   icon: Icons.favorite_border,
                  //   text: S.of(context).Wishlist,
                  // ),
                  // GButton(icon: Icons.category, text: S.of(context).Shopping),
                  // GButton(icon: Icons.person, text: S.of(context).profile),
                ],
              ),
            ),
          ),
          body: IndexedStack(
            index: currentIndex,
            children: [
              const CoffeeAppHomeScreen(),

              OrdersScreen(),
               ProfileScreen(),
              // OfferScreen(),
              // NewCartScreen(),
              // WishListScreen(),
              // NewCategoryScreen(),
              // CustomDrawer(),
            ],
          ),
        );
      },
    );
  }
}
