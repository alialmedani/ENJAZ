// import 'package:enjaz/core/constant/app_colors/app_colors.dart';
// import 'package:enjaz/core/constant/app_padding/app_padding.dart';
// import 'package:enjaz/core/constant/text_styles/font_size.dart';
// import 'package:enjaz/features/home/data/model/icon_model.dart';
// import 'package:flutter/material.dart';

// class CoffeeAppMainScreen extends StatefulWidget {
//   const CoffeeAppMainScreen({super.key});

//   @override
//   State<CoffeeAppMainScreen> createState() => _CoffeeAppMainScreenState();
// }

// class _CoffeeAppMainScreenState extends State<CoffeeAppMainScreen> {
//   int indexMenu = 0;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.xbackgroundColor,
//       body: menu[indexMenu]['destination'] as Widget,
//       bottomNavigationBar: Padding(
//         padding: const EdgeInsets.symmetric(
//           horizontal: AppPaddingSize.padding_30,
//         ),
//         child: Row(
//           children: List.generate(menu.length, (index) {
//             final Map items = menu[index];
//             final bool isActive = indexMenu == index;

//             return Expanded(
//               child: InkWell(
//                 onTap: () => setState(() => indexMenu = index),
//                 child: SizedBox(
//                   height: AppFontSize.size_70,
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       SizedBox(height: AppFontSize.size_20),
//                       Icon(
//                         items['icon'],
//                         color: isActive
//                             ? AppColors.xprimaryColor
//                             : AppColors.secondPrimery,
//                         size: AppFontSize.size_25,
//                       ),
//                       if (isActive) SizedBox(height: AppFontSize.size_7),
//                       if (isActive)
//                         Container(
//                           height: AppFontSize.size_5,
//                           width: AppFontSize.size_15,
//                           decoration: BoxDecoration(
//                             color: AppColors.xprimaryColor,
//                             borderRadius: BorderRadius.circular(
//                               AppFontSize.size_20,
//                             ),
//                           ),
//                         ),
//                     ],
//                   ),
//                 ),
//               ),
//             );
//           }),
//         ),
//       ),
//     );
//   }
// }
