// lib/features/order/coffee_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:enjaz/core/constant/app_colors/app_colors.dart';
import 'package:enjaz/core/constant/app_padding/app_padding.dart';
import 'package:enjaz/core/constant/text_styles/app_text_style.dart';
import 'package:enjaz/core/constant/text_styles/font_size.dart';

import 'package:enjaz/features/order/data/datasource/menu_static_data_source.dart';
import 'package:enjaz/features/order/data/model/order_menu.dart';
import 'package:enjaz/features/order/cubit/corder_cubit.dart';
import 'package:enjaz/features/profile/cubit/profile_cubit.dart';

class CoffeeDetailScreen extends StatefulWidget {
  const CoffeeDetailScreen({super.key, required this.itemId});

  final String itemId; // مثال: 'latte', 'capp', 'espresso'...

  static Route route({required String itemId}) {
    return PageRouteBuilder(
      settings: RouteSettings(name: 'CoffeeDetail:$itemId'),
      pageBuilder: (_, __, ___) => CoffeeDetailScreen(itemId: itemId),
      transitionsBuilder: (_, anim, __, child) {
        final curved = CurvedAnimation(
          parent: anim,
          curve: Curves.easeOutCubic,
        );
        return FadeTransition(
          opacity: curved,
          child: ScaleTransition(
            scale: Tween<double>(begin: .98, end: 1).animate(curved),
            child: child,
          ),
        );
      },
    );
  }

  @override
  State<CoffeeDetailScreen> createState() => _CoffeeDetailScreenState();
}

class _CoffeeDetailScreenState extends State<CoffeeDetailScreen> {
  MenuItem? _item;
  String _size = 'M';
  int _qty = 1;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final bundle = await MenuStaticDataSource().getMenu();
    final found = bundle.items.firstWhere(
      (e) => e.id == widget.itemId,
      orElse: () => bundle.items.first,
    );
    setState(() => _item = found);
  }

  double get _unitPrice => _item?.priceFor(_size) ?? 0;
  double get _total => _unitPrice * _qty;

  @override
  Widget build(BuildContext context) {
    final monthDay = DateFormat('MMM d', 'ar');

    return BlocProvider(
      create: (_) => OrderCubit(),
      child: Scaffold(
        body: _item == null
            ? Center(
                child: CircularProgressIndicator(
                  color: AppColors.xprimaryColor,
                ),
              )
            : CustomScrollView(
                slivers: [
                  SliverAppBar(
                    pinned: true,
                    expandedHeight: 220,
                    flexibleSpace: FlexibleSpaceBar(
                      title: Text(
                        _item!.name,
                        style: AppTextStyle.getBoldStyle(
                          fontSize: AppFontSize.size_14,
                          color: AppColors.white,
                        ),
                      ),
                      background: Stack(
                        fit: StackFit.expand,
                        children: [
                          Container(
                            color: AppColors.xprimaryColor.withOpacity(.25),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Hero(
                              tag: 'coffee-${_item!.id}',
                              child: _CoffeeHeroArt(),
                            ),
                          ),
                          Positioned(
                            right: 16,
                            bottom: 16,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black26,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                monthDay.format(DateTime.now()),
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'الحجم',
                            style: AppTextStyle.getBoldStyle(
                              fontSize: AppFontSize.size_14,
                              color: AppColors.black23,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              _sizeChip('S'),
                              const SizedBox(width: 8),
                              _sizeChip('M'),
                              const SizedBox(width: 8),
                              _sizeChip('L'),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'الكمية',
                            style: AppTextStyle.getBoldStyle(
                              fontSize: AppFontSize.size_14,
                              color: AppColors.black23,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              borderRadius: BorderRadius.circular(
                                AppPaddingSize.padding_12,
                              ),
                              border: Border.all(color: AppColors.greyE5),
                            ),
                            child: Row(
                              children: [
                                IconButton(
                                  onPressed: () => setState(
                                    () => _qty = _qty > 1 ? _qty - 1 : 1,
                                  ),
                                  icon: const Icon(Icons.remove),
                                ),
                                Expanded(
                                  child: Center(
                                    child: AnimatedSwitcher(
                                      duration: const Duration(
                                        milliseconds: 160,
                                      ),
                                      child: Text(
                                        '$_qty',
                                        key: ValueKey(_qty),
                                        style: AppTextStyle.getBoldStyle(
                                          fontSize: AppFontSize.size_16,
                                          color: AppColors.black23,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                IconButton(
                                  onPressed: () => setState(() => _qty++),
                                  icon: const Icon(Icons.add),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          _PriceRow(unit: _unitPrice, total: _total),
                          const SizedBox(height: 120),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
        bottomSheet: _item == null
            ? null
            : _BottomBar(
                label: 'تأكيد الطلب',
                total: _total,
                onPressed: () async {
                  // جرّب قراءة بروفايل للحصول على الاسم والموقع الافتراضي
                  String buyer = 'مستخدم إنجاز';
                  int floor = 1, office = 1;
                  try {
                    final p = context.read<ProfileCubit>().state;
                    if (p != null) {
                      buyer = p.name;
                      floor = p.defaultFloor;
                      office = p.defaultOffice;
                    }
                  } catch (_) {
                    // لا يوجد ProfileCubit أعلى الشجرة — نستخدم القيم الافتراضية
                  }

                  final orderCubit = context.read<OrderCubit>()
                    ..setItemName(_item!.name)
                    ..setSize(_size)
                    ..setQuantity(_qty)
                    ..setBuyerName(buyer)
                    ..setFloor(floor)
                    ..setOffice(office);

                  // لودينغ سريع
                  showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) =>
                        const Center(child: CircularProgressIndicator()),
                  );

                  final res = await orderCubit.createOrder();

                  if (mounted) Navigator.of(context).pop(); // أغلق اللودينغ

                  final ok = res.hasDataOnly;
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          ok
                              ? 'تم تأكيد الطلب'
                              : (res.error ?? 'تعذّر إنشاء الطلب'),
                        ),
                        backgroundColor: ok
                            ? AppColors.xprimaryColor
                            : AppColors.secondPrimery,
                      ),
                    );
                    if (ok)
                      Navigator.of(context).maybePop(); // ارجع من شاشة التفاصيل
                  }
                },
              ),
      ),
    );
  }

  Widget _sizeChip(String s) {
    final selected = _size == s;
    return InkWell(
      onTap: () => setState(() => _size = s),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.xprimaryColor.withOpacity(.12)
              : AppColors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? AppColors.xprimaryColor : AppColors.greyE5,
          ),
        ),
        child: Text(
          s,
          style: AppTextStyle.getBoldStyle(
            fontSize: AppFontSize.size_14,
            color: selected ? AppColors.xprimaryColor : AppColors.black23,
          ),
        ),
      ),
    );
  }
}

class _CoffeeHeroArt extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      height: 120,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.xprimaryColor.withOpacity(.15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Icon(Icons.local_cafe, size: 58, color: Colors.white),
    );
  }
}

class _PriceRow extends StatelessWidget {
  final double unit;
  final double total;
  const _PriceRow({required this.unit, required this.total});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
        border: Border.all(color: AppColors.greyE5),
      ),
      child: Row(
        children: [
          Text(
            'سعر الكوب',
            style: AppTextStyle.getRegularStyle(
              fontSize: AppFontSize.size_12,
              color: AppColors.secondPrimery,
            ),
          ),
          const Spacer(),
          Text(
            '${unit.toStringAsFixed(2)} ر.س',
            style: AppTextStyle.getBoldStyle(
              fontSize: AppFontSize.size_14,
              color: AppColors.black23,
            ),
          ),
        ],
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  final String label;
  final double total;
  final VoidCallback onPressed;
  const _BottomBar({
    required this.label,
    required this.total,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
      decoration: BoxDecoration(
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 10,
            offset: const Offset(0, -4),
          ),
        ],
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(14),
          topRight: Radius.circular(14),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Text(
                  'الإجمالي',
                  style: AppTextStyle.getBoldStyle(
                    fontSize: AppFontSize.size_16,
                    color: AppColors.black23,
                  ),
                ),
                const Spacer(),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 160),
                  child: Text(
                    '${total.toStringAsFixed(2)} ر.س',
                    key: ValueKey(total.toStringAsFixed(2)),
                    style: AppTextStyle.getBoldStyle(
                      fontSize: AppFontSize.size_18,
                      color: AppColors.xprimaryColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppPaddingSize.padding_12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: onPressed,
                icon: const Icon(Icons.check),
                label: Text(label),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
