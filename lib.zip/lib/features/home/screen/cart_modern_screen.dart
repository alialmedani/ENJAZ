// import 'package:flutter/material.dart';
// import 'package:enjaz/core/constant/app_colors/app_colors.dart';
// import 'package:enjaz/core/constant/app_padding/app_padding.dart';
// import 'package:enjaz/core/constant/text_styles/app_text_style.dart';
// import 'package:enjaz/core/constant/text_styles/font_size.dart';

// class _CartItem {
//   final String name, subtitle, image;
//   int qty;
//   final double price;
//   _CartItem({
//     required this.name,
//     required this.subtitle,
//     required this.image,
//     required this.qty,
//     required this.price,
//   });
// }

// class CartModernScreen extends StatefulWidget {
//   const CartModernScreen({super.key});

//   @override
//   State<CartModernScreen> createState() => _CartModernScreenState();
// }

// class _CartModernScreenState extends State<CartModernScreen> {
//   final _items = <_CartItem>[
//     _CartItem(
//       name: 'Espresso',
//       subtitle: 'with milk',
//       image: 'assets/images/espresso.png',
//       qty: 1,
//       price: 2.5,
//     ),
//     _CartItem(
//       name: 'Latte',
//       subtitle: 'with bakery',
//       image: 'assets/images/latte.png',
//       qty: 1,
//       price: 3.2,
//     ),
//   ];

//   double get _subtotal => _items.fold(0, (p, e) => p + e.price * e.qty);
//   double get _shipping => 1.0;
//   double get _taxes => 1.0;
//   double get _total => _subtotal + _shipping + _taxes;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.evenLighterBackground,
//       appBar: AppBar(
//         backgroundColor: AppColors.primary,
//         title: Text(
//           'Cart',
//           style: AppTextStyle.getBoldStyle(
//             fontSize: AppFontSize.size_16,
//             color: AppColors.white,
//           ),
//         ),
//       ),
//       body: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(AppPaddingSize.padding_20),
//             child: Align(
//               alignment: Alignment.centerLeft,
//               child: Text(
//                 'My Order',
//                 style: AppTextStyle.getBoldStyle(
//                   fontSize: AppFontSize.size_18,
//                   color: AppColors.black23,
//                 ),
//               ),
//             ),
//           ),
//           Expanded(
//             child: ListView.separated(
//               padding: const EdgeInsets.symmetric(
//                 horizontal: AppPaddingSize.padding_20,
//               ),
//               itemCount: _items.length,
//               separatorBuilder: (_, __) =>
//                   const SizedBox(height: AppPaddingSize.padding_12),
//               itemBuilder: (_, i) => _row(_items[i]),
//             ),
//           ),

//           // فاتورة
//           Container(
//             decoration: const BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
//             ),
//             padding: const EdgeInsets.all(AppPaddingSize.padding_20),
//             child: Column(
//               children: [
//                 _billRow('Subtotal', _subtotal),
//                 _billRow('Shipping Cost', _shipping),
//                 _billRow('Taxes', _taxes),
//                 const SizedBox(height: AppPaddingSize.padding_8),
//                 const Divider(),
//                 const SizedBox(height: AppPaddingSize.padding_8),
//                 _billRow('Total', _total, bold: true),
//                 const SizedBox(height: AppPaddingSize.padding_12),
//                 SizedBox(
//                   width: double.infinity,
//                   height: AppPaddingSize.padding_52,
//                   child: ElevatedButton(
//                     onPressed: () {},
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: const Color(0xff2b0b11),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(16),
//                       ),
//                     ),
//                     child: Text(
//                       '\$${_total.toStringAsFixed(1)}  •  Proceed to Checkout',
//                       style: AppTextStyle.getBoldStyle(
//                         fontSize: AppFontSize.size_16,
//                         color: AppColors.white,
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _row(_CartItem it) {
//     return Container(
//       decoration: BoxDecoration(
//         color: AppColors.white,
//         borderRadius: BorderRadius.circular(18),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(.04),
//             blurRadius: 8,
//             offset: const Offset(0, 6),
//           ),
//         ],
//       ),
//       padding: const EdgeInsets.all(AppPaddingSize.padding_12),
//       child: Row(
//         children: [
//           ClipRRect(
//             borderRadius: BorderRadius.circular(12),
//             child: Image.asset(
//               it.image,
//               height: 60,
//               width: 60,
//               fit: BoxFit.cover,
//             ),
//           ),
//           const SizedBox(width: AppPaddingSize.padding_12),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   it.name,
//                   style: AppTextStyle.getBoldStyle(
//                     fontSize: AppFontSize.size_16,
//                     color: AppColors.black23,
//                   ),
//                 ),
//                 Text(
//                   it.subtitle,
//                   style: AppTextStyle.getRegularStyle(
//                     fontSize: AppFontSize.size_12,
//                     color: AppColors.xsecondaryColor,
//                   ),
//                 ),
//                 const SizedBox(height: 4),
//                 Text(
//                   '\$${it.price.toStringAsFixed(2)}',
//                   style: AppTextStyle.getBoldStyle(
//                     fontSize: AppFontSize.size_14,
//                     color: AppColors.black23,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           _qtyBtn(
//             icon: Icons.remove,
//             onTap: () {
//               setState(() => it.qty = it.qty > 1 ? it.qty - 1 : 1);
//             },
//           ),
//           Padding(
//             padding: const EdgeInsets.symmetric(
//               horizontal: AppPaddingSize.padding_12,
//             ),
//             child: Text(
//               '${it.qty}',
//               style: AppTextStyle.getBoldStyle(
//                 fontSize: AppFontSize.size_16,
//                 color: AppColors.black23,
//               ),
//             ),
//           ),
//           _qtyBtn(
//             icon: Icons.add,
//             onTap: () {
//               setState(() => it.qty++);
//             },
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _qtyBtn({required IconData icon, required VoidCallback onTap}) {
//     return InkWell(
//       onTap: onTap,
//       borderRadius: BorderRadius.circular(10),
//       child: Ink(
//         width: 32,
//         height: 32,
//         decoration: BoxDecoration(
//           color: AppColors.white,
//           borderRadius: BorderRadius.circular(10),
//           border: Border.all(color: AppColors.greyDD),
//         ),
//         child: Icon(icon, size: 18),
//       ),
//     );
//   }

//   Widget _billRow(String label, double value, {bool bold = false}) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: AppPaddingSize.padding_6),
//       child: Row(
//         children: [
//           Text(
//             label,
//             style: (bold
//                 ? AppTextStyle.getBoldStyle(
//                     fontSize: AppFontSize.size_14,
//                     color: AppColors.black23,
//                   )
//                 : AppTextStyle.getRegularStyle(
//                     fontSize: AppFontSize.size_14,
//                     color: AppColors.grey8E,
//                   )),
//           ),
//           const Spacer(),
//           Text(
//             '\$${value.toStringAsFixed(1)}',
//             style: (bold
//                 ? AppTextStyle.getBoldStyle(
//                     fontSize: AppFontSize.size_16,
//                     color: AppColors.black23,
//                   )
//                 : AppTextStyle.getSemiBoldStyle(
//                     fontSize: AppFontSize.size_14,
//                     color: AppColors.black23,
//                   )),
//           ),
//         ],
//       ),
//     );
//   }
// }
