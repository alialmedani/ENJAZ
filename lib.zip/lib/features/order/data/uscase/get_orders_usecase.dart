import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/features/order/data/model/order_model.dart';
import '../../data/repository/order_repository.dart';
 
class GetOrdersUsecase {
  final OrderRepository _repo;
  GetOrdersUsecase(this._repo);

  Future<Result<List<OrderModel>>> call() => _repo.getOrders();
}
