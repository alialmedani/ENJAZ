import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/features/order/data/model/order_model.dart';
import '../datasource/order_static_data_source.dart';
 import '../model/params/create_order_params.dart';

class OrderRepository {
  final IOrderStaticDataSource _ds;
  OrderRepository({IOrderStaticDataSource? dataSource})
    : _ds = dataSource ?? OrderStaticDataSource();

  Future<Result<List<OrderModel>>> getOrders() async {
    try {
      final list = await _ds.getOrders();
      return Result<List<OrderModel>>(data: list);
    } catch (e) {
      return Result<List<OrderModel>>(error: _map(e));
    }
  }

  Future<Result<OrderModel>> createOrder(CreateOrderParams params) async {
    try {
      final m = await _ds.createOrder(params);
      return Result<OrderModel>(data: m);
    } catch (e) {
      return Result<OrderModel>(error: _map(e));
    }
  }

  String _map(Object e) {
    final s = e.toString();
    if (s.contains('INVALID_ITEM')) return 'الطلب غير صالح.';
    if (s.contains('INVALID_SIZE')) return 'الحجم غير صالح (S/M/L).';
    if (s.contains('INVALID_BUYER')) return 'اسم الزبون مطلوب.';
    if (s.contains('INVALID_FLOOR')) return 'رقم الطابق 1 إلى 5.';
    if (s.contains('INVALID_OFFICE')) return 'رقم المكتب 1 إلى 6.';
    return 'حدث خطأ غير متوقع.';
  }
}
