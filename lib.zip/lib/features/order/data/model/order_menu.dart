// lib/features/order/data/model/order_menu.dart
class MenuItem {
  final String id;
  final String name;
  final double priceS;
  final double priceM;
  final double priceL;

  const MenuItem({
    required this.id,
    required this.name,
    required this.priceS,
    required this.priceM,
    required this.priceL,
  });

  double priceFor(String size) {
    switch (size) {
      case 'S':
        return priceS;
      case 'L':
        return priceL;
      case 'M':
      default:
        return priceM;
    }
  }
}

class ExtraOption {
  final String id;
  final String name;
  final double price;

  const ExtraOption({
    required this.id,
    required this.name,
    required this.price,
  });
}

class MenuBundle {
  final List<MenuItem> items;
  final List<ExtraOption> extras;

  const MenuBundle({required this.items, required this.extras});
}
