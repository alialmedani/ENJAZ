// lib/features/order/data/model/options_enums.dart
enum SugarLevel { none, less, normal, extra }

enum MilkType { none, regular, skim, almond, soy }

enum Temperature { cold, warm, hot }

extension SugarLevelX on SugarLevel {
  String get ar {
    switch (this) {
      case SugarLevel.none:
        return 'بدون سكر';
      case SugarLevel.less:
        return 'سكر قليل';
      case SugarLevel.normal:
        return 'عادي';
      case SugarLevel.extra:
        return 'سكر زيادة';
    }
  }

  String get value => toString().split('.').last;
}

extension MilkTypeX on MilkType {
  String get ar {
    switch (this) {
      case MilkType.none:
        return 'بدون حليب';
      case MilkType.regular:
        return 'حليب عادي';
      case MilkType.skim:
        return 'حليب خالي الدسم';
      case MilkType.almond:
        return 'لوز';
      case MilkType.soy:
        return 'صويا';
    }
  }

  String get value => toString().split('.').last;
}

extension TemperatureX on Temperature {
  String get ar {
    switch (this) {
      case Temperature.cold:
        return 'بارد';
      case Temperature.warm:
        return 'دافئ';
      case Temperature.hot:
        return 'حار';
    }
  }

  String get value => toString().split('.').last;
}
