import 'package:flutter_bloc/flutter_bloc.dart';

class OrderListCubit extends Cubit<String> {
  // القيمة تمثّل الحالة المختارة: 'pending' / 'ready' / 'done'
  OrderListCubit() : super('pending');

  void select(String status) {
    if (state != status) emit(status);
  }
}
