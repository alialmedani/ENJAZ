import 'package:bloc/bloc.dart';
import 'package:enjaz/features/home/data/model/coffee_model.dart';

class OrderComposerState {
  final Coffee? coffee; // الصنف المختار
  final String size; // S/M/L
  final int quantity;
  final int sugar; // 0..5
  final bool milk;
  final String temperature; // hot/cold
  final List<String> extras; // أسماء الإضافات
  final String? note;
  final int floor;
  final int office;
  final DateTime? scheduledAt;
  final double unitPrice; // قبل الضرب بالكمية
  final double totalPrice; // بعد الضرب

  const OrderComposerState({
    this.coffee,
    this.size = 'M',
    this.quantity = 1,
    this.sugar = 0,
    this.milk = false,
    this.temperature = 'hot',
    this.extras = const [],
    this.note,
    this.floor = 1,
    this.office = 1,
    this.scheduledAt,
    this.unitPrice = 0,
    this.totalPrice = 0,
  });

  OrderComposerState copyWith({
    Coffee? coffee,
    String? size,
    int? quantity,
    int? sugar,
    bool? milk,
    String? temperature,
    List<String>? extras,
    String? note,
    int? floor,
    int? office,
    DateTime? scheduledAt,
    double? unitPrice,
    double? totalPrice,
  }) => OrderComposerState(
    coffee: coffee ?? this.coffee,
    size: size ?? this.size,
    quantity: quantity ?? this.quantity,
    sugar: sugar ?? this.sugar,
    milk: milk ?? this.milk,
    temperature: temperature ?? this.temperature,
    extras: extras ?? this.extras,
    note: note ?? this.note,
    floor: floor ?? this.floor,
    office: office ?? this.office,
    scheduledAt: scheduledAt ?? this.scheduledAt,
    unitPrice: unitPrice ?? this.unitPrice,
    totalPrice: totalPrice ?? this.totalPrice,
  );
}

class OrderComposerCubit extends Cubit<OrderComposerState> {
  OrderComposerCubit() : super(const OrderComposerState());

  // سياسة التسعير:
  // base = coffee.price
  // sizeMultiplier: S=1.0, M=1.2, L=1.4
  // extras: لكل إضافة تسعيرة ثابتة (مثال)
  // milk/sugar: مجانية
  // temperature: بدون فرق
  static const _sizeMul = {'S': 1.0, 'M': 1.2, 'L': 1.4};
  static const _extrasPrice = <String, double>{
    'Extra Shot': 1.5,
    'Caramel Syrup': 1.0,
    'Whipped Cream': 0.5,
    'Almond Milk': 0.8,
  };

  void selectCoffee(Coffee c) {
    emit(_reprice(state.copyWith(coffee: c)));
  }

  void setSize(String s) => emit(_reprice(state.copyWith(size: s)));
  void setQuantity(int q) => emit(_reprice(state.copyWith(quantity: q)));
  void setSugar(int v) => emit(_reprice(state.copyWith(sugar: v)));
  void setMilk(bool v) => emit(state.copyWith(milk: v));
  void setTemperature(String t) => emit(state.copyWith(temperature: t));
  void toggleExtra(String name, bool add) {
    final set = {...state.extras};
    if (add) {
      set.add(name);
    } else {
      set.remove(name);
    }
    emit(_reprice(state.copyWith(extras: set.toList())));
  }

  void setNote(String? n) => emit(state.copyWith(note: n));
  void setFloor(int f) => emit(state.copyWith(floor: f));
  void setOffice(int o) => emit(state.copyWith(office: o));
  void setSchedule(DateTime? at) => emit(state.copyWith(scheduledAt: at));

  OrderComposerState _reprice(OrderComposerState s) {
    final base = s.coffee?.price ?? 0.0;
    final mul = _sizeMul[s.size] ?? 1.0;
    final extras = s.extras.fold<double>(
      0.0,
      (acc, e) => acc + (_extrasPrice[e] ?? 0),
    );
    final unit = (base * mul) + extras;
    final total = unit * (s.quantity.clamp(1, 50));
    return s.copyWith(unitPrice: unit, totalPrice: total);
  }
}
