// lib/features/order/orders_screen.dart
import 'package:enjaz/core/boilerplate/get_model/widgets/get_model.dart';
import 'package:enjaz/core/boilerplate/create_model/widgets/create_model.dart';
import 'package:enjaz/core/constant/app_colors/app_colors.dart';
import 'package:enjaz/core/constant/app_padding/app_padding.dart';
import 'package:enjaz/core/constant/text_styles/font_size.dart';
import 'package:enjaz/core/constant/text_styles/app_text_style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:enjaz/features/order/cubit/corder_cubit.dart';
import 'package:enjaz/features/order/data/model/order_model.dart';
import 'package:enjaz/features/order/data/model/order_status.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  static const bool kReorderEnabled = true; // عطّل/فعّل زر "إعادة الطلب"

  Color _statusBg(OrderStatus s) {
    switch (s) {
      case OrderStatus.pending:
        return AppColors.lightOrange.withOpacity(.15);
      case OrderStatus.ready:
        return AppColors.lightGreen.withOpacity(.15);
      case OrderStatus.done:
        return AppColors.greyE5.withOpacity(.45);
    }
  }

  Color _statusFg(OrderStatus s) {
    switch (s) {
      case OrderStatus.pending:
        return AppColors.lightOrange;
      case OrderStatus.ready:
        return AppColors.green32;
      case OrderStatus.done:
        return AppColors.secondPrimery;
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => OrderCubit(),
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'طلبات القهوة',
            style: AppTextStyle.getBoldStyle(
              fontSize: AppFontSize.size_16,
              color: AppColors.white,
            ),
          ),
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(AppPaddingSize.padding_16),
          child: GetModel<List<OrderModel>>(
            useCaseCallBack: () => context.read<OrderCubit>().getOrders(),
            // Pull-to-refresh مفعّل تلقائيًا عبر GetModel
            modelBuilder: (list) {
              final pending = list
                  .where((e) => e.status == OrderStatus.pending)
                  .toList();
              final ready = list
                  .where((e) => e.status == OrderStatus.ready)
                  .toList();
              final done = list
                  .where((e) => e.status == OrderStatus.done)
                  .toList();

              return DefaultTabController(
                length: 3,
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(
                          AppPaddingSize.padding_12,
                        ),
                      ),
                      child: TabBar(
                        indicatorColor: AppColors.xprimaryColor,
                        labelColor: AppColors.xprimaryColor,
                        unselectedLabelColor: AppColors.secondPrimery,
                        tabs: [
                          Tab(text: 'قيد التنفيذ (${pending.length})'),
                          Tab(text: 'جاهز (${ready.length})'),
                          Tab(text: 'تم (${done.length})'),
                        ],
                      ),
                    ),
                    const SizedBox(height: AppPaddingSize.padding_12),
                    Expanded(
                      child: TabBarView(
                        children: [
                          _OrdersList(
                            items: pending,
                            statusBg: _statusBg,
                            statusFg: _statusFg,
                            reorderEnabled: kReorderEnabled,
                          ),
                          _OrdersList(
                            items: ready,
                            statusBg: _statusBg,
                            statusFg: _statusFg,
                            reorderEnabled: kReorderEnabled,
                          ),
                          _OrdersList(
                            items: done,
                            statusBg: _statusBg,
                            statusFg: _statusFg,
                            reorderEnabled: kReorderEnabled,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
            loading: Center(
              child: CircularProgressIndicator(color: AppColors.xprimaryColor),
            ),
            onError: (msg) {
              final message = (msg?.toString().isNotEmpty ?? false)
                  ? msg.toString()
                  : 'حدث خطأ غير متوقع';
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(message),
                  backgroundColor: AppColors.secondPrimery,
                ),
              );
            },
          ),
        ),
        floatingActionButton: const _AddOrderFab(),
      ),
    );
  }
}

class _OrdersList extends StatelessWidget {
  final List<OrderModel> items;
  final Color Function(OrderStatus) statusBg;
  final Color Function(OrderStatus) statusFg;
  final bool reorderEnabled;

  const _OrdersList({
    required this.items,
    required this.statusBg,
    required this.statusFg,
    required this.reorderEnabled,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(height: AppPaddingSize.padding_24),
          Center(
            child: Text(
              'لا توجد طلبات هنا بعد',
              style: AppTextStyle.getRegularStyle(
                fontSize: AppFontSize.size_14,
                color: AppColors.secondPrimery,
              ),
            ),
          ),
        ],
      );
    }

    return ListView.separated(
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: items.length,
      separatorBuilder: (_, __) =>
          const SizedBox(height: AppPaddingSize.padding_12),
      itemBuilder: (_, i) => _OrderCard(
        m: items[i],
        statusBg: statusBg(items[i].status),
        statusFg: statusFg(items[i].status),
        reorderEnabled: reorderEnabled,
      ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  final OrderModel m;
  final Color statusBg;
  final Color statusFg;
  final bool reorderEnabled;

  const _OrderCard({
    required this.m,
    required this.statusBg,
    required this.statusFg,
    required this.reorderEnabled,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: AppFontSize.size_48,
            height: AppFontSize.size_48,
            decoration: BoxDecoration(
              color: AppColors.xprimaryColor.withOpacity(.1),
              borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
            ),
            alignment: Alignment.center,
            child: Icon(Icons.local_cafe, color: AppColors.xprimaryColor),
          ),
          const SizedBox(width: AppPaddingSize.padding_12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // الاسم + الحجم
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        m.itemName,
                        style: AppTextStyle.getBoldStyle(
                          fontSize: AppFontSize.size_16,
                          color: AppColors.black23,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: AppPaddingSize.padding_8),
                    Text(
                      m.size,
                      style: AppTextStyle.getRegularStyle(
                        fontSize: AppFontSize.size_14,
                        color: AppColors.secondPrimery,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppPaddingSize.padding_4),
                // الزبون + الموقع
                Text(
                  'الزبون: ${m.buyerName}',
                  style: AppTextStyle.getRegularStyle(
                    fontSize: AppFontSize.size_14,
                    color: AppColors.black23,
                  ),
                ),
                const SizedBox(height: AppPaddingSize.padding_4),
                Text(
                  'الموقع: طابق ${m.floor} - مكتب ${m.office}',
                  style: AppTextStyle.getRegularStyle(
                    fontSize: AppFontSize.size_14,
                    color: AppColors.secondPrimery,
                  ),
                ),
                const SizedBox(height: AppPaddingSize.padding_12),
                // شارة الحالة + إعادة طلب (اختياري)
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppPaddingSize.padding_8,
                        vertical: AppPaddingSize.padding_4,
                      ),
                      decoration: BoxDecoration(
                        color: statusBg,
                        borderRadius: BorderRadius.circular(
                          AppPaddingSize.padding_8,
                        ),
                      ),
                      child: Text(
                        m.status.ar,
                        style: AppTextStyle.getBoldStyle(
                          fontSize: AppFontSize.size_12,
                          color: statusFg,
                        ),
                      ),
                    ),
                    const Spacer(),
                    if (reorderEnabled)
                      TextButton.icon(
                        onPressed: () async {
                          final res = await context.read<OrderCubit>().reorder(
                            m,
                          );
                      
                        },
                        icon: const Icon(Icons.refresh),
                        label: const Text('إعادة الطلب'),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AddOrderFab extends StatelessWidget {
  const _AddOrderFab();

  @override
  Widget build(BuildContext context) {
    return CreateModel<OrderModel>(
      useCaseCallBack: (_) => context.read<OrderCubit>().createOrder(),
      withValidation: false,
      onSuccess: (_) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('تم إنشاء طلب'),
            backgroundColor: AppColors.xprimaryColor,
          ),
        );
      },
      child: FloatingActionButton.extended(
        onPressed: null, // CreateModel هو الذي يتكفّل بالضغط
        backgroundColor: AppColors.xprimaryColor,
        label: const Text('إنشاء طلب'),
        icon: const Icon(Icons.add),
      ),
    );
  }
}
