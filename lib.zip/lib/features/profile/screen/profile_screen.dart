// lib/features/profile/profile_screen.dart
import 'package:enjaz/features/profile/data/repo/profile_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

import 'package:enjaz/core/boilerplate/get_model/widgets/get_model.dart';
import 'package:enjaz/core/constant/app_colors/app_colors.dart';
import 'package:enjaz/core/constant/app_padding/app_padding.dart';
import 'package:enjaz/core/constant/text_styles/app_text_style.dart';
import 'package:enjaz/core/constant/text_styles/font_size.dart';

import 'package:enjaz/features/profile/cubit/profile_cubit.dart';
import 'package:enjaz/features/profile/data/model/user_profile.dart';
import 'package:enjaz/features/profile/data/model/order_history_entry.dart';
import 'package:enjaz/features/profile/data/usecase/get_profile_usecase.dart';
import 'package:enjaz/features/profile/data/usecase/get_order_history_usecase.dart';

import 'package:enjaz/features/order/cubit/corder_cubit.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tab;
  DateTime? _selectedPrevMonth; // للشهور السابقة
  final _repo = ProfileRepository();

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  // ملخص شهر محدّد
  Map<String, dynamic> _buildSummary(List<OrderHistoryEntry> list) {
    final count = list.length;
    double total = 0;
    final Map<String, int> byDrink = {};
    for (final e in list) {
      total += e.totalPrice;
      final k = e.order.itemName;
      byDrink[k] = (byDrink[k] ?? 0) + e.quantity;
    }
    String topDrink = '-';
    if (byDrink.isNotEmpty) {
      final sorted = byDrink.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      topDrink = sorted.first.key;
    }
    return {'count': count, 'total': total, 'topDrink': topDrink};
  }

  @override
  Widget build(BuildContext context) {
    final monthFormat = DateFormat('yyyy-MM');

    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => ProfileCubit()),
        BlocProvider(create: (_) => OrderCubit()),
      ],
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'الملف الشخصي',
            style: AppTextStyle.getBoldStyle(
              fontSize: AppFontSize.size_16,
              color: AppColors.white,
            ),
          ),
          bottom: TabBar(
            controller: _tab,
            tabs: const [
              Tab(text: 'نظرة عامة'),
              Tab(text: 'السجلّ'),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tab,
          children: [
            // ====== تبويب نظرة عامة ======
            Padding(
              padding: const EdgeInsets.all(AppPaddingSize.padding_16),
              child: GetModel<UserProfile>(
                useCaseCallBack: () => GetProfileUsecase(_repo).call(),
                modelBuilder: (profile) {
                  context.read<ProfileCubit>().setProfile(profile);
                  return ListView(
                    children: [
                      _Header(profile: profile),
                      const SizedBox(height: AppPaddingSize.padding_16),
                      _SettingsCard(profile: profile),
                      const SizedBox(height: AppPaddingSize.padding_16),
                      _FavoritesRow(profile: profile),
                      const SizedBox(height: AppPaddingSize.padding_16),
                      _LogoutCard(),
                    ],
                  );
                },
                loading: Center(
                  child: CircularProgressIndicator(
                    color: AppColors.xprimaryColor,
                  ),
                ),
              ),
            ),

            // ====== تبويب السجلّ ======
            Padding(
              padding: const EdgeInsets.all(AppPaddingSize.padding_16),
              child: StatefulBuilder(
                builder: (context, setLocal) {
                  // شريط الفلاتر أعلى السجلّ
                  final thisMonth = DateTime(
                    DateTime.now().year,
                    DateTime.now().month,
                  );
                  final chosenMonth = (_tab.index == 0)
                      ? thisMonth
                      : (_selectedPrevMonth ?? thisMonth);

                  return Column(
                    children: [
                      _HistoryFilters(
                        selectedPrevMonth: _selectedPrevMonth,
                        onSelectPrevMonth: (d) {
                          setLocal(() => _selectedPrevMonth = d);
                        },
                      ),
                      const SizedBox(height: AppPaddingSize.padding_12),

                      Expanded(
                        child: GetModel<List<OrderHistoryEntry>>(
                          useCaseCallBack: () =>
                              GetOrderHistoryUsecase(_repo).call(
                                month:
                                    (_selectedPrevMonth == null &&
                                        _tab.index == 1)
                                    ? DateTime(
                                        DateTime.now().year,
                                        DateTime.now().month - 1,
                                      )
                                    : (_tab.index == 0
                                          ? DateTime(
                                              DateTime.now().year,
                                              DateTime.now().month,
                                            )
                                          : _selectedPrevMonth),
                              ),
                          modelBuilder: (list) {
                            final summary = _buildSummary(list);
                            return Column(
                              children: [
                                _SummaryCard(
                                  monthLabel: monthFormat.format(
                                    (_tab.index == 0) ? thisMonth : chosenMonth,
                                  ),
                                  count: summary['count'] as int,
                                  total: summary['total'] as double,
                                  topDrink: summary['topDrink'] as String,
                                ),
                                const SizedBox(
                                  height: AppPaddingSize.padding_12,
                                ),
                                Expanded(child: _HistoryList(entries: list)),
                              ],
                            );
                          },
                          loading: Center(
                            child: CircularProgressIndicator(
                              color: AppColors.xprimaryColor,
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final UserProfile profile;
  const _Header({required this.profile});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: AppColors.greyE5,
            backgroundImage: profile.avatarUrl != null
                ? NetworkImage(profile.avatarUrl!)
                : null,
            child: profile.avatarUrl == null
                ? Icon(Icons.person, color: AppColors.secondPrimery, size: 28)
                : null,
          ),
          const SizedBox(width: AppPaddingSize.padding_12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  profile.name,
                  style: AppTextStyle.getBoldStyle(
                    fontSize: AppFontSize.size_16,
                    color: AppColors.black23,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Floor ${profile.defaultFloor} • Office ${profile.defaultOffice}',
                  style: AppTextStyle.getRegularStyle(
                    fontSize: AppFontSize.size_12,
                    color: AppColors.secondPrimery,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsCard extends StatefulWidget {
  final UserProfile profile;
  const _SettingsCard({required this.profile});

  @override
  State<_SettingsCard> createState() => _SettingsCardState();
}

class _SettingsCardState extends State<_SettingsCard> {
  late AppLanguage _lang;
  late bool _notif;
  late int _floor;
  late int _office;

  @override
  void initState() {
    super.initState();
    _lang = widget.profile.language;
    _notif = widget.profile.notificationsEnabled;
    _floor = widget.profile.defaultFloor;
    _office = widget.profile.defaultOffice;
  }

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ProfileCubit>();
    final p = cubit.state ?? widget.profile;

    return Container(
      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'الإعدادات',
            style: AppTextStyle.getBoldStyle(
              fontSize: AppFontSize.size_14,
              color: AppColors.black23,
            ),
          ),
          const SizedBox(height: AppPaddingSize.padding_12),
          // لغة
          DropdownButtonFormField<AppLanguage>(
            decoration: const InputDecoration(
              labelText: 'لغة التطبيق',
              border: OutlineInputBorder(),
            ),
            value: _lang,
            items: const [
              DropdownMenuItem(value: AppLanguage.ar, child: Text('العربية')),
              DropdownMenuItem(value: AppLanguage.en, child: Text('English')),
            ],
            onChanged: (v) => setState(() => _lang = v ?? _lang),
          ),
          const SizedBox(height: AppPaddingSize.padding_12),
          // إشعارات
          SwitchListTile(
            title: const Text('تفعيل الإشعارات'),
            value: _notif,
            onChanged: (v) => setState(() => _notif = v),
          ),
          const SizedBox(height: AppPaddingSize.padding_12),
          // الموقع الافتراضي
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<int>(
                  decoration: const InputDecoration(
                    labelText: 'Floor (افتراضي)',
                    border: OutlineInputBorder(),
                  ),
                  value: _floor,
                  items: List.generate(5, (i) => i + 1)
                      .map((f) => DropdownMenuItem(value: f, child: Text('$f')))
                      .toList(),
                  onChanged: (v) => setState(() => _floor = v ?? _floor),
                ),
              ),
              const SizedBox(width: AppPaddingSize.padding_12),
              Expanded(
                child: DropdownButtonFormField<int>(
                  decoration: const InputDecoration(
                    labelText: 'Office (افتراضي)',
                    border: OutlineInputBorder(),
                  ),
                  value: _office,
                  items: List.generate(6, (i) => i + 1)
                      .map((o) => DropdownMenuItem(value: o, child: Text('$o')))
                      .toList(),
                  onChanged: (v) => setState(() => _office = v ?? _office),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppPaddingSize.padding_12),

          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () async {
                    final next = p.copyWith(
                      language: _lang,
                      notificationsEnabled: _notif,
                      defaultFloor: _floor,
                      defaultOffice: _office,
                    );
                    final res = await cubit.updateSettings(next);
                    final ok = res.hasDataOnly;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          ok ? 'تم حفظ الإعدادات' : (res.error ?? 'فشل الحفظ'),
                        ),
                        backgroundColor: ok
                            ? AppColors.xprimaryColor
                            : AppColors.secondPrimery,
                      ),
                    );
                    if (ok) setState(() {}); // تحديث العرض
                  },
                  icon: const Icon(Icons.save),
                  label: const Text('حفظ'),
                ),
              ),
              const SizedBox(width: AppPaddingSize.padding_12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    // Placeholder: لاحقًا توليد PDF ومشاركة
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text('تصدير PDF قريبًا'),
                        backgroundColor: AppColors.secondPrimery,
                      ),
                    );
                  },
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('تصدير PDF (لاحقًا)'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FavoritesRow extends StatelessWidget {
  final UserProfile profile;
  const _FavoritesRow({required this.profile});

  @override
  Widget build(BuildContext context) {
    final orderCubit = context.read<OrderCubit>();
    final profileCubit = context.read<ProfileCubit>();
    final buyer = profile.name;

    if (profile.favorites.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'المفضّلة',
            style: AppTextStyle.getBoldStyle(
              fontSize: AppFontSize.size_14,
              color: AppColors.black23,
            ),
          ),
          const SizedBox(height: AppPaddingSize.padding_12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: profile.favorites.map((name) {
                return Padding(
                  padding: const EdgeInsets.only(
                    right: AppPaddingSize.padding_8,
                  ),
                  child: ActionChip(
                    label: Text(name),
                    avatar: const Icon(Icons.bolt),
                    onPressed: () async {
                      final res = await profileCubit.quickReorder(
                        orderCubit: orderCubit,
                        itemName: name,
                        size: 'M',
                        buyerName: buyer,
                        floor: profile.defaultFloor,
                        office: profile.defaultOffice,
                      );
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            res.hasDataOnly ? 'تم الطلب السريع' : 'تعذّر الطلب',
                          ),
                          backgroundColor: res.hasDataOnly
                              ? AppColors.xprimaryColor
                              : AppColors.secondPrimery,
                        ),
                      );
                    },
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _LogoutCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
      ),
      child: Row(
        children: [
          const Icon(Icons.logout),
          const SizedBox(width: AppPaddingSize.padding_12),
          Expanded(
            child: Text(
              'تسجيل الخروج',
              style: AppTextStyle.getBoldStyle(
                fontSize: AppFontSize.size_14,
                color: AppColors.black23,
              ),
            ),
          ),
          TextButton(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('تأكيد تسجيل الخروج'),
                  content: const Text('هل تريد الخروج من الحساب؟'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: const Text('إلغاء'),
                    ),
                    ElevatedButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: const Text('خروج'),
                    ),
                  ],
                ),
              );
              if (ok == true) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: const Text('تم تسجيل الخروج')),
                );
                Navigator.of(context).maybePop();
              }
            },
            child: const Text('خروج'),
          ),
        ],
      ),
    );
  }
}
class _HistoryFilters extends StatefulWidget {
  final DateTime? selectedPrevMonth;
  final ValueChanged<DateTime?> onSelectPrevMonth;

  const _HistoryFilters({
    required this.selectedPrevMonth,
    required this.onSelectPrevMonth,
  });

  @override
  State<_HistoryFilters> createState() => _HistoryFiltersState();
}

class _HistoryFiltersState extends State<_HistoryFilters>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min, // مهم: لا يطلب ارتفاعًا لا نهائيًا
      children: [
        Container(
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
          ),
          child: TabBar(
            controller: _tabs,
            onTap: (i) {
              // لا تحرّك التاب الأساسي للشاشة!
              setState(() {}); // فقط حدّث عرض الفلتر
            },
            tabs: const [
              Tab(text: 'هذا الشهر'),
              Tab(text: 'الشهور السابقة'),
            ],
          ),
        ),
        const SizedBox(height: AppPaddingSize.padding_12),

        // بدل TabBarView: عرض شرطي لمحتوى تبويب "الشهور السابقة"
        if (_tabs.index == 1)
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final now = DateTime.now();
                    final first = DateTime(now.year, now.month - 5);
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: now,
                      firstDate: first,
                      lastDate: now,
                      helpText: 'اختر أي يوم من الشهر المطلوب',
                    );
                    if (picked != null) {
                      widget.onSelectPrevMonth(
                        DateTime(picked.year, picked.month),
                      );
                    }
                  },
                  icon: const Icon(Icons.date_range),
                  label: Text(
                    widget.selectedPrevMonth == null
                        ? 'اختر الشهر'
                        : DateFormat(
                            'yyyy-MM',
                          ).format(widget.selectedPrevMonth!),
                  ),
                ),
              ),
              const SizedBox(width: AppPaddingSize.padding_8),
              if (widget.selectedPrevMonth != null)
                IconButton(
                  onPressed: () => widget.onSelectPrevMonth(null),
                  icon: const Icon(Icons.clear),
                ),
            ],
          )
        else
          const SizedBox.shrink(),
      ],
    );
  }
}


class _SummaryCard extends StatelessWidget {
  final String monthLabel;
  final int count;
  final double total;
  final String topDrink;

  const _SummaryCard({
    required this.monthLabel,
    required this.count,
    required this.total,
    required this.topDrink,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppPaddingSize.padding_16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                'ملخّص $monthLabel',
                style: AppTextStyle.getBoldStyle(
                  fontSize: AppFontSize.size_14,
                  color: AppColors.black23,
                ),
              ),
              const Spacer(),
              TextButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: const Text('مشاركة الملخّص قريبًا')),
                  );
                },
                icon: const Icon(Icons.share),
                label: const Text('مشاركة'),
              ),
            ],
          ),
          const SizedBox(height: AppPaddingSize.padding_12),
          Row(
            children: [
              _StatTile(title: 'الطلبات', value: '$count'),
              _StatTile(
                title: 'الإجمالي',
                value: '${total.toStringAsFixed(2)} ر.س',
              ),
              _StatTile(title: 'الأكثر طلبًا', value: topDrink),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final String title;
  final String value;
  const _StatTile({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.only(right: AppPaddingSize.padding_8),
        padding: const EdgeInsets.all(AppPaddingSize.padding_12),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
          border: Border.all(color: AppColors.greyE5),
        ),
        child: Column(
          children: [
            Text(
              title,
              style: AppTextStyle.getRegularStyle(
                fontSize: AppFontSize.size_12,
                color: AppColors.secondPrimery,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              value,
              textAlign: TextAlign.center,
              style: AppTextStyle.getBoldStyle(
                fontSize: AppFontSize.size_14,
                color: AppColors.black23,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HistoryList extends StatelessWidget {
  final List<OrderHistoryEntry> entries;
  const _HistoryList({required this.entries});

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 32),
          Center(
            child: Text(
              'لا توجد طلبات في هذا الشهر',
              style: AppTextStyle.getRegularStyle(
                fontSize: AppFontSize.size_14,
                color: AppColors.secondPrimery,
              ),
            ),
          ),
        ],
      );
    }

    final orderCubit = context.read<OrderCubit>();
    final profile = context.read<ProfileCubit>().state;

    return ListView.separated(
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: entries.length,
      separatorBuilder: (_, __) =>
          const SizedBox(height: AppPaddingSize.padding_12),
      itemBuilder: (_, i) {
        final e = entries[i];
        return Container(
          padding: const EdgeInsets.all(AppPaddingSize.padding_16),
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(AppPaddingSize.padding_12),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.xprimaryColor.withOpacity(.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.local_cafe),
              ),
              const SizedBox(width: AppPaddingSize.padding_12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // اسم + حجم + تاريخ
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${e.order.itemName} • ${e.order.size}',
                            style: AppTextStyle.getBoldStyle(
                              fontSize: AppFontSize.size_14,
                              color: AppColors.black23,
                            ),
                          ),
                        ),
                        Text(
                          DateFormat('yyyy-MM-dd').format(e.createdAt),
                          style: AppTextStyle.getRegularStyle(
                            fontSize: AppFontSize.size_12,
                            color: AppColors.secondPrimery,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'الكمية: ${e.quantity}',
                      style: AppTextStyle.getRegularStyle(
                        fontSize: AppFontSize.size_12,
                        color: AppColors.black23,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'الإجمالي: ${e.totalPrice.toStringAsFixed(2)} ر.س',
                      style: AppTextStyle.getBoldStyle(
                        fontSize: AppFontSize.size_14,
                        color: AppColors.xprimaryColor,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        OutlinedButton.icon(
                          onPressed: () async {
                            final res = await context
                                .read<ProfileCubit>()
                                .quickReorder(
                                  orderCubit: orderCubit,
                                  itemName: e.order.itemName,
                                  size: e.order.size,
                                  buyerName: e.order.buyerName,
                                  floor: profile?.defaultFloor ?? e.order.floor,
                                  office:
                                      profile?.defaultOffice ?? e.order.office,
                                );
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  res.hasDataOnly
                                      ? 'تمت إعادة الطلب'
                                      : 'تعذّرت إعادة الطلب',
                                ),
                                backgroundColor: res.hasDataOnly
                                    ? AppColors.xprimaryColor
                                    : AppColors.secondPrimery,
                              ),
                            );
                          },
                          icon: const Icon(Icons.refresh),
                          label: const Text('إعادة الطلب'),
                        ),
                        const SizedBox(width: 8),
                        TextButton.icon(
                          onPressed: () {
                            // لاحقًا يمكن فتح تفاصيل/مشاركة
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: const Text('سيتوفر المزيد قريبًا'),
                              ),
                            );
                          },
                          icon: const Icon(Icons.more_horiz),
                          label: const Text('المزيد'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
