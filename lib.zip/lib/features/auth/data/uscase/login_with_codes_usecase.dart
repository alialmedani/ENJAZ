import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/features/auth/data/model/login_params.dart';
import 'package:enjaz/features/auth/data/repo/auth_repository_impl.dart';
import '../model/login_model.dart';
 

class LoginUsecase {
  final AuthRepository _repo;
  LoginUsecase(AuthRepository repo) : _repo = repo;

  Future<Result<LoginModel>> call({required LoginParams params}) {
    return _repo.loginRequest(params: params);
  }
}
