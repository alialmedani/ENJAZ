class LoginModel {
  final String? accessToken;
  final String? tokenType;
  final int? expiresIn;
  final String? refreshToken;

  LoginModel({
    this.accessToken,
    this.tokenType,
    this.expiresIn,
    this.refreshToken,
  });

  factory LoginModel.fromStatic(String token) => LoginModel(
    accessToken: token,
    tokenType: 'bearer',
    expiresIn: 3600,
    refreshToken: 'static-refresh',
  );
}
