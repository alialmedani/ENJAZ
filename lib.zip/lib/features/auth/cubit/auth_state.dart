import 'package:enjaz/features/auth/data/model/auth_session.dart';

 
abstract class AuthState {
  const AuthState();
}

class AuthInitial extends AuthState {
  const AuthInitial();
}

class AuthLoading extends AuthState {
  const AuthLoading();
}

class AuthSuccess extends AuthState {
  final AuthSession session;
  const AuthSuccess(this.session);
}

class AuthFailure extends AuthState {
  final String message;
  const AuthFailure(this.message);
}
