
const baseUrl = 'https://task.jasim-erp.com/';


const getlistdrink = '${baseUrl}api/app/drink'; // GET


/////order url////////////

const String createDrinkOrderUrl = '${baseUrl}api/app/order';
const String getOrdersUrl = '${baseUrl}api/app/order';
const String getCurrentUserOrdersUrl = '${baseUrl}api/app/Order/current_user';
 const String createDrinkOrderLiteUrl = "$baseUrl/api/app/order";
/////auth_url////////////
///
const loginUrl = '${baseUrl}connect/token';
const registerUrl = '${baseUrl}api/app/users/mobile-register';


///user url////////////

const currentUserUrl = '${baseUrl}api/app/current-customer';
const getPlaceUrl = '${baseUrl}api/app/floor/offices/autocomplete';


