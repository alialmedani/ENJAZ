part of 'drink_cubit.dart';

@immutable
sealed class DrinkState {}

final class DrinkInitial extends DrinkState {}
