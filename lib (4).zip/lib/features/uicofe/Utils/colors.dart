import 'package:flutter/material.dart';

const firstColor = Color(0xFF3A825F);
const secondColor = Color(0xFF3F966C);
const thirdColor = Color(0xFF48A878);
