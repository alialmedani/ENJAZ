part of 'place_cubit.dart';

@immutable
sealed class PlaceState {}

final class PlaceInitial extends PlaceState {}
