part of 'order_cubit.dart';

 sealed class OrderState {}

final class OrderInitial extends OrderState {}
