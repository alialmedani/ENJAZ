// lib/features/order/cubit/corder_cubit.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/features/order/data/model/order_model.dart';
import 'package:enjaz/features/order/data/model/params/create_order_params.dart';
import 'package:enjaz/features/order/data/repository/order_repository.dart';
import 'package:enjaz/features/order/data/uscase/get_orders_usecase.dart';
import 'package:enjaz/features/order/data/uscase/create_order_usecase.dart';

class OrderCubit extends Cubit<void> {
  OrderCubit() : super(null);

  final CreateOrderParams createParams = CreateOrderParams();

  // Basic setters (موجودة سابقاً)
  void setItemName(String v) => createParams.itemName = v;
  void setSize(String v) => createParams.size = v;
  void setBuyerName(String v) => createParams.buyerName = v;
  void setFloor(int v) => createParams.floor = v;
  void setOffice(int v) => createParams.office = v;

  // Advanced setters
  void setQuantity(int v) => createParams.quantity = v;
  void setSugar(String v) => createParams.sugarLevel = v;
  void setMilk(String v) => createParams.milkType = v;
  void setTemp(String v) => createParams.temperature = v;
  void setExtras(List<String> ids) => createParams.extras = ids;
  void setNote(String? v) =>
      createParams.note = (v?.trim().isEmpty ?? true) ? null : v!.trim();
  void setScheduledAt(DateTime? dt) => createParams.scheduledAt = dt;

  Future<Result<List<OrderModel>>> getOrders() async {
    final usecase = GetOrdersUsecase(OrderRepository());
    return usecase.call();
  }

  Future<Result<OrderModel>> createOrder() async {
    final usecase = CreateOrderUsecase(OrderRepository());
    return usecase.call(createParams);
  }

  Future<Result<OrderModel>> reorder(OrderModel prev) async {
    final p = CreateOrderParams()
      ..itemName = prev.itemName
      ..size = prev.size
      ..buyerName = prev.buyerName
      ..floor = prev.floor
      ..office = prev.office
      ..quantity = 1;
    final usecase = CreateOrderUsecase(OrderRepository());
    return usecase.call(p);
  }
}
