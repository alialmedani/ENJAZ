// lib/features/order/orders_screen.dart
 import 'package:enjaz/core/boilerplate/get_model/widgets/get_model.dart';
import 'package:enjaz/core/constant/app_colors/app_colors.dart';
 import 'package:enjaz/core/constant/text_styles/app_text_style.dart';
import 'package:enjaz/core/constant/text_styles/font_size.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:enjaz/features/order/cubit/corder_cubit.dart';
import 'package:enjaz/features/order/data/model/order_model.dart';
 
class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => OrderCubit(),
      child: Scaffold(
        backgroundColor: AppColors.xbackgroundColor2,
        appBar: AppBar(
          backgroundColor:  AppColors.xbackgroundColor2,
          elevation: 0,
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded),
            onPressed: () => Navigator.of(context).maybePop(),
          ),
          title: Text(
            'Cart',
            style: AppTextStyle.getBoldStyle(
              fontSize: AppFontSize.size_16,
              color: AppColors.black,
            ),
          ),
          
        ),
        body: GetModel<List<OrderModel>>(
          useCaseCallBack: () => context.read<OrderCubit>().getOrders(),
          loading: Center(
            child: CircularProgressIndicator(color: AppColors.xprimaryColor),
          ),
          modelBuilder: (list) {
            final lines = list.map(_CartLine.fromOrder).toList();
            return _CartBody(lines: lines);
          },
        ),
      ),
    );
  }
}

/// ====== Line model (safe reads) ======
class _CartLine {
  final OrderModel raw;
  final String title;
  final String subtitle;
  final String? image;
  int qty;
  final double price;

  _CartLine({
    required this.raw,
    required this.title,
    required this.subtitle,
    required this.image,
    required this.qty,
    required this.price,
  });

  static T? _read<T>(OrderModel m, T? Function(dynamic d) pick) {
    try {
      final d = m as dynamic;
      return pick(d);
    } catch (_) {
      return null;
    }
  }

  factory _CartLine.fromOrder(OrderModel m) {
    final title = _read<String>(m, (d) => d.itemName as String?) ?? 'Coffee';
    final size = _read<String>(m, (d) => d.size as String?) ?? '';
    final subtitle = size.isEmpty ? 'with milk' : 'with $size';

    final image = _read<String>(m, (d) => d.image as String?);

    final qtyNum = _read<num>(m, (d) => d.quantity as num?) ?? 1;
    final priceNum = _read<num>(m, (d) => d.price as num?) ?? 0;

    return _CartLine(
      raw: m,
      title: title,
      subtitle: subtitle,
      image: image,
      qty: qtyNum.toInt().clamp(1, 99),
      price: priceNum.toDouble(),
    );
  }

  double get lineTotal => price * qty;
}

class _CartBody extends StatefulWidget {
  final List<_CartLine> lines;
  const _CartBody({required this.lines});

  @override
  State<_CartBody> createState() => _CartBodyState();
}

class _CartBodyState extends State<_CartBody> {
  double get _subTotal => widget.lines.fold(0.0, (s, e) => s + e.lineTotal);
@override
  Widget build(BuildContext context) {
    
    final total = _subTotal;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // كل المحتوى العادي ضمن بادنغ
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'My Order',
                  style: AppTextStyle.getBoldStyle(
                    fontSize: AppFontSize.size_18,
                    color: AppColors.black,
                  ),
                ),
                const SizedBox(height: 4),
                RichText(
                  text: TextSpan(
                    style: AppTextStyle.getRegularStyle(
                      fontSize: AppFontSize.size_12,
                      color: AppColors.secondPrimery,
                    ),
                    children: [
                      const TextSpan(text: 'You have '),
                      TextSpan(
                        text: '${widget.lines.length} items',
                        style: AppTextStyle.getBoldStyle(
                          fontSize: AppFontSize.size_12,
                          color: const Color(0xFFD95B2B),
                        ),
                      ),
                      const TextSpan(text: ' in your cart.'),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // العناصر
                ...List.generate(widget.lines.length, (i) {
                  final line = widget.lines[i];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _CartItemTile(
                      line: line,
                      onQtyChanged: (q) => setState(() => line.qty = q),
                    ),
                  );
                }),
              ],
            ),
          ),

          // مسافة صغيرة قبل الشريط
          const SizedBox(height: 6),

          // CTA البنفسجي خارج البادنغ ➜ صار Full-bleed (عرض كامل)
          _BottomArcCTA(
            depth: 90,
            curveAtTop: false, // القوس من الأسفل
            priceText: '\$${total.toStringAsFixed(1)}',
            buttonText: 'Proceed to Checkout',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Total: \$${total.toStringAsFixed(2)}'),
                  backgroundColor:  AppColors.xpurpleColor,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

}

// ============================== Item Tile ==============================
class _CartItemTile extends StatefulWidget {
  final _CartLine line;
  final ValueChanged<int> onQtyChanged;

  const _CartItemTile({required this.line, required this.onQtyChanged});

  @override
  State<_CartItemTile> createState() => _CartItemTileState();
}

class _CartItemTileState extends State<_CartItemTile> {
  late int _qty;

  @override
  void initState() {
    super.initState();
    _qty = widget.line.qty;
  }

  void _setQty(int v) {
    setState(() => _qty = v.clamp(1, 99));
    widget.onQtyChanged(_qty);
  }

  @override
  Widget build(BuildContext context) {
 
    return Container(
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: widget.line.image != null
                ? Image.asset(
                    widget.line.image!,
                    width: 64,
                    height: 64,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => _coffeeFallback(),
                  )
                : _coffeeFallback(),
          ),
          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.line.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyle.getBoldStyle(
                    fontSize: AppFontSize.size_16,
                    color: AppColors.black,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  widget.line.subtitle,
                  style: AppTextStyle.getRegularStyle(
                    fontSize: AppFontSize.size_12,
                    color: AppColors.secondPrimery,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '\$${widget.line.price.toStringAsFixed(2)}',
                  style: AppTextStyle.getBoldStyle(
                    fontSize: AppFontSize.size_14,
                    color: AppColors.xorangeColor,
                  ),
                ),
              ],
            ),
          ),

          _MiniQtyChip(value: _qty, onChanged: _setQty),
        ],
      ),
    );
  }

  Widget _coffeeFallback() => Container(
    width: 64,
    height: 64,
    color: AppColors.xprimaryColor.withOpacity(.08),
    child: Icon(Icons.local_cafe, color: AppColors.xprimaryColor),
  );
}

class _MiniQtyChip extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;

  const _MiniQtyChip({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
 
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFEFE4DE)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _iconBtn(
            icon: Icons.remove,
            onTap: () => onChanged((value - 1).clamp(1, 99)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              '$value',
              style: AppTextStyle.getBoldStyle(
                fontSize: AppFontSize.size_14,
                color: AppColors.black,
              ),
            ),
          ),
          _iconBtn(
            icon: Icons.add,
            onTap: () => onChanged((value + 1).clamp(1, 99)),
          ),
        ],
      ),
    );
  }

  Widget _iconBtn({required IconData icon, required VoidCallback onTap}) {
     return InkResponse(
      onTap: onTap,
      radius: 18,
      child: Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.xorangeColor),
          color: AppColors.white,
        ),
        child: Icon(icon, size: 16, color: AppColors.xorangeColor),
      ),
    );
  }
}

// ========================== Arc clippers & CTA ==========================

/// Clipper مرن: إما قوس من الأعلى أو من الأسفل
class _ArcClipper extends CustomClipper<Path> {
  final double depth; // عمق القوس
  final bool curveAtTop; // true= قوس من الأعلى، false= من الأسفل
  const _ArcClipper({this.depth = 90, this.curveAtTop = false});

  @override
  Path getClip(Size size) {
    final d = depth.clamp(20.0, size.height - 1).toDouble();

    if (curveAtTop) {
      // ┌ موجة من الأعلى
      return Path()
        ..lineTo(0, d)
        ..quadraticBezierTo(size.width / 2, 0, size.width, d)
        ..lineTo(size.width, size.height)
        ..lineTo(0, size.height)
        ..close();
    } else {
      // └ موجة من الأسفل
      return Path()
        ..lineTo(size.width, 0)
        ..lineTo(size.width, size.height - d)
        ..quadraticBezierTo(size.width / 2, size.height, 0, size.height - d)
        ..lineTo(0, 0)
        ..close();
    }
  }

  @override
  bool shouldReclip(covariant _ArcClipper old) =>
      old.depth != depth || old.curveAtTop != curveAtTop;
}

class _BottomArcCTA extends StatelessWidget {
  final String priceText;
  final String buttonText;
  final VoidCallback onTap;

  final double depth;
  final bool curveAtTop; // خليها false لعمل الانحناء من تحت

  const _BottomArcCTA({
    required this.priceText,
    required this.buttonText,
    required this.onTap,
    this.depth = 90,
    this.curveAtTop = false,
  });

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF2A0C24);

    // لما يكون القوس من تحت، بنحتاج padding سفلي أكبر ليسع الانحناء
    final EdgeInsets pad = curveAtTop
        ? EdgeInsets.fromLTRB(16, depth, 16, 18)
        : EdgeInsets.fromLTRB(16, 18, 16, depth);

    return ClipPath(
      clipper: _ArcClipper(depth: depth, curveAtTop: curveAtTop),
      child: Container(
        width: double.infinity,
        color: purple,
        padding: pad,
        child: Column(
          children: [
            Text(
              priceText,
              style: AppTextStyle.getBoldStyle(
                fontSize: AppFontSize.size_16,
                color: AppColors.white,
              ),
            ),
            const SizedBox(height: 6),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  foregroundColor: AppColors.white
                ),
                onPressed: onTap,
                child: Text(
                  buttonText,
                  style: AppTextStyle.getBoldStyle(
                    fontSize: AppFontSize.size_14,
                    color: AppColors.white
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
