// lib/features/order/data/datasource/menu_static_data_source.dart
import 'package:enjaz/features/order/data/model/order_menu.dart';

abstract class IMenuStaticDataSource {
  Future<MenuBundle> getMenu();
}

class MenuStaticDataSource implements IMenuStaticDataSource {
  @override
  Future<MenuBundle> getMenu() async {
    await Future.delayed(const Duration(milliseconds: 250));
    const items = [
      MenuItem(
        id: 'espresso',
        name: 'Espresso',
        priceS: 7,
        priceM: 9,
        priceL: 11,
      ),
      MenuItem(id: 'latte', name: 'Latte', priceS: 9, priceM: 11, priceL: 13),
      MenuItem(
        id: 'capp',
        name: 'Cappuccino',
        priceS: 9,
        priceM: 11,
        priceL: 13,
      ),
      MenuItem(
        id: 'americano',
        name: 'Americano',
        priceS: 8,
        priceM: 10,
        priceL: 12,
      ),
      MenuItem(id: 'mocha', name: 'Mocha', priceS: 10, priceM: 12, priceL: 14),
    ];
    const extras = [
      ExtraOption(id: 'shot', name: 'Extra Shot', price: 2.5),
      ExtraOption(id: 'syrup', name: 'Syrup', price: 1.5),
      ExtraOption(id: 'cream', name: 'Whipped', price: 1.0),
      ExtraOption(id: 'choco', name: 'Chocolate', price: 1.5),
      ExtraOption(id: 'caramel', name: 'Caramel', price: 1.5),
    ];
    return const MenuBundle(items: items, extras: extras);
  }
}
