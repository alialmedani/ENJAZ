import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/features/order/data/model/order_model.dart';
import '../../data/repository/order_repository.dart';
 import '../../data/model/params/create_order_params.dart';

class CreateOrderUsecase {
  final OrderRepository _repo;
  CreateOrderUsecase(this._repo);

  Future<Result<OrderModel>> call(CreateOrderParams params) =>
      _repo.createOrder(params);
}
