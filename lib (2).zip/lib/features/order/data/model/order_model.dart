// lib/features/order/data/model/order_model.dart
import 'order_status.dart';

class OrderModel {
  final String id;
  final String itemName; // شو الطلب
  final String size; // حجمه (S/M/L)
  final String buyerName; // اسم الزبون
  final int floor; // الطابق (1..5)
  final int office; // المكتب (1..6)
  final OrderStatus status; // حالة الطلب

  OrderModel({
    required this.id,
    required this.itemName,
    required this.size,
    required this.buyerName,
    required this.floor,
    required this.office,
    this.status = OrderStatus.pending,
  });

  factory OrderModel.fromMap(Map<String, dynamic> m) => OrderModel(
    id: m['id'] as String,
    itemName: m['itemName'] as String,
    size: m['size'] as String,
    buyerName: m['buyerName'] as String,
    floor: m['floor'] as int,
    office: m['office'] as int,
    status: OrderStatusX.parse(m['status'] as String?),
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'itemName': itemName,
    'size': size,
    'buyerName': buyerName,
    'floor': floor,
    'office': office,
    'status': status.value,
  };

  OrderModel copyWith({
    String? id,
    String? itemName,
    String? size,
    String? buyerName,
    int? floor,
    int? office,
    OrderStatus? status,
  }) {
    return OrderModel(
      id: id ?? this.id,
      itemName: itemName ?? this.itemName,
      size: size ?? this.size,
      buyerName: buyerName ?? this.buyerName,
      floor: floor ?? this.floor,
      office: office ?? this.office,
      status: status ?? this.status,
    );
  }
}
