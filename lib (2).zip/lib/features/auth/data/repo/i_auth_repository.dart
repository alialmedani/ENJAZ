import 'dart:convert';
import 'package:enjaz/core/classes/cashe_helper.dart';
import 'package:enjaz/core/constant/end_points/cashe_helper_constant.dart';
import '../../data/model/login_model.dart';
import '../../data/model/register_model.dart';

abstract class IAuthStaticDataSource {
  Future<LoginModel> loginWithPhone(String phone, String password);
  Future<RegisterModel> registerWithDetails({
    required String username,
    required String phone,
    required String password,
    required int floor,
    required int office,
  });
}

class AuthStaticDataSource implements IAuthStaticDataSource {
  static const _usersKey =
      'auth_users_map'; // Map<String, dynamic> phone -> Map
  static const _currentKey = 'current_user_phone';

  // seed مبدئي (مستخدم تجريبي)
  static final Map<String, dynamic> _seed = {
    '0999123456': {
      'username': 'Demo',
      'password': '0000',
      'floor': 1,
      'office': 1,
    },
  };

  Future<Map<String, dynamic>> _loadUsers() async {
    try {
      final raw = CacheHelper.box.get(_usersKey);
      if (raw == null) {
        await CacheHelper.box.put(_usersKey, jsonEncode(_seed));
        return Map<String, dynamic>.from(_seed);
      }
      final map = jsonDecode(raw as String) as Map<String, dynamic>;
      return map;
    } catch (_) {
      // fallback in-memory
      return Map<String, dynamic>.from(_seed);
    }
  }

  Future<void> _saveUsers(Map<String, dynamic> users) async {
    try {
      await CacheHelper.box.put(_usersKey, jsonEncode(users));
    } catch (_) {
      /* ignore */
    }
  }

  @override
  Future<LoginModel> loginWithPhone(String phone, String password) async {
    final users = await _loadUsers();
    if (!users.containsKey(phone)) throw Exception('PHONE_NOT_FOUND');

    final entry = users[phone];
    // دعم نسخة قديمة كانت تخزن "password" كسلسلة فقط
    if (entry is String) {
      if (entry != password) throw Exception('WRONG_PASSWORD');
    } else if (entry is Map<String, dynamic>) {
      if ((entry['password']?.toString() ?? '') != password) {
        throw Exception('WRONG_PASSWORD');
      }
    } else {
      throw Exception('CORRUPTED_USER');
    }

    final token = 'static-token-${DateTime.now().millisecondsSinceEpoch}';
    try {
      await CacheHelper.box.put(accessToken, token);
      await CacheHelper.box.put(refreshToken, 'static-refresh');
      await CacheHelper.box.put(_currentKey, phone);
    } catch (_) {
      /* ignore */
    }
    return LoginModel.fromStatic(token);
  }

  @override
  Future<RegisterModel> registerWithDetails({
    required String username,
    required String phone,
    required String password,
    required int floor,
    required int office,
  }) async {
    if (floor < 1 || floor > 5) throw Exception('INVALID_FLOOR');
    if (office < 1 || office > 6) throw Exception('INVALID_OFFICE');
    if (password.length < 6) throw Exception('WEAK_PASSWORD');

    final users = await _loadUsers();
    if (users.containsKey(phone)) throw Exception('PHONE_EXISTS');

    users[phone] = {
      'username': username.trim(),
      'password': password,
      'floor': floor,
      'office': office,
    };
    await _saveUsers(users);

    return RegisterModel.success(phone);
  }
}
