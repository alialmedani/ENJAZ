import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/features/auth/data/model/login_params.dart';
import 'package:enjaz/features/auth/data/model/register_params.dart';
import 'package:enjaz/features/auth/data/repo/i_auth_repository.dart';
 import '../model/login_model.dart';
import '../model/register_model.dart';
  
class AuthRepository {
  final IAuthStaticDataSource _ds;
  AuthRepository({IAuthStaticDataSource? dataSource})
    : _ds = dataSource ?? AuthStaticDataSource();

  Future<Result<LoginModel>> loginRequest({required LoginParams params}) async {
    try {
      final model = await _ds.loginWithPhone(
        params.phone.trim(),
        params.password,
      );
      return Result<LoginModel>(data: model);
    } catch (e) {
      return Result<LoginModel>(error: _mapErr(e));
    }
  }

  Future<Result<RegisterModel>> registerRequest({
    required RegisterParams params,
  }) async {
    try {
      final model = await _ds.registerWithDetails(
        username: params.username.trim(),
        phone: params.phone.trim(),
        password: params.password,
        floor: params.floor,
        office: params.office,
      );
      return Result<RegisterModel>(data: model);
    } catch (e) {
      return Result<RegisterModel>(error: _mapErr(e));
    }
  }

  String _mapErr(Object e) {
    final s = e.toString();
    if (s.contains('PHONE_EXISTS')) return 'رقم الهاتف مسجّل مسبقًا.';
    if (s.contains('WEAK_PASSWORD'))
      return 'كلمة المرور ضعيفة (6 أحرف على الأقل).';
    if (s.contains('INVALID_FLOOR')) return 'رقم الطابق غير صالح (1 إلى 5).';
    if (s.contains('INVALID_OFFICE')) return 'رقم المكتب غير صالح (1 إلى 6).';
    if (s.contains('PHONE_NOT_FOUND')) return 'رقم الهاتف غير موجود.';
    if (s.contains('WRONG_PASSWORD')) return 'كلمة المرور غير صحيحة.';
    return 'حدث خطأ غير متوقع.';
  }
}
