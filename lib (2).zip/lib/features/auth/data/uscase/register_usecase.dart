import 'package:enjaz/core/results/result.dart';
import 'package:enjaz/features/auth/data/model/register_params.dart';
import 'package:enjaz/features/auth/data/repo/auth_repository_impl.dart';
import '../model/register_model.dart';
 

class RegisterUsecase {
  final AuthRepository _repo;
  RegisterUsecase(this._repo);

  Future<Result<RegisterModel>> call({required RegisterParams params}) {
    return _repo.registerRequest(params: params);
  }
}