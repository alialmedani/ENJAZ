class LoginParams {
  String phone;
  String password;
  LoginParams({this.phone = '', this.password = ''});
}
