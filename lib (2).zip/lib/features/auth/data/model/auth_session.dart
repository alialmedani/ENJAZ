class AuthSession {
  final String token;
  final String userName;
  const AuthSession({required this.token, required this.userName});
}
