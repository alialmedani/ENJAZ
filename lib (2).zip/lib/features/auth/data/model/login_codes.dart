class LoginCodes {
  final String code1;
  final String code2;
  const LoginCodes({required this.code1, required this.code2});
}
