import 'package:enjaz/features/auth/data/model/login_params.dart';
import 'package:enjaz/features/auth/data/model/register_params.dart';
import 'package:enjaz/features/auth/data/repo/auth_repository_impl.dart';
import 'package:enjaz/features/auth/data/uscase/login_with_codes_usecase.dart';
import 'package:enjaz/features/auth/data/uscase/register_usecase.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:enjaz/core/results/result.dart';

import '../data/model/login_model.dart';
import '../data/model/register_model.dart';

class AuthCubit extends Cubit<void> {
  AuthCubit() : super(null);

  LoginParams loginParams = LoginParams();
  RegisterParams registerParams = RegisterParams();

  // Login
  void setLoginPhone(String v) => loginParams.phone = v;
  void setLoginPassword(String v) => loginParams.password = v;

  Future<Result<LoginModel>> login() async {
    final usecase = LoginUsecase(AuthRepository());
    return usecase.call(params: loginParams);
  }

  // Register
  void setRegisterUsername(String v) => registerParams.username = v;
  void setRegisterPhone(String v) => registerParams.phone = v;
  void setRegisterPassword(String v) => registerParams.password = v;
  void setRegisterFloor(int v) => registerParams.floor = v;
  void setRegisterOffice(int v) => registerParams.office = v;

  Future<Result<RegisterModel>> sigup() async {
    final usecase = RegisterUsecase(AuthRepository());
    return usecase.call(params: registerParams);
  }
}
