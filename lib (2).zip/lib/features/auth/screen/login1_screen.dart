// import 'package:enjaz/core/constant/app_colors/app_colors.dart';
// import 'package:flutter/material.dart';

// class LoginScreen1 extends StatelessWidget {
//   const LoginScreen1({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(backgroundColor: AppColors.babyBlue,
//       body: Column(
//         children: [
//           Stack(
//             children: [
//               SizedBox(
//                 height: MediaQuery.of(context).size.height / 1.5,
//                 width: MediaQuery.of(context).size.width,
               
//               ),
//               Positioned(
//                 top: 100,
//                 left: 170,
//                 child: Text(
//                   "Login",
//                   style: TextStyle(
//                     fontSize: 35,
//                     fontWeight: FontWeight.bold,
//                     color: AppColors.white,
//                   ),
//                 ),
//               ),
//               Positioned(
//                 top: 200,
//                 left: 65,
//                 child: usernameTextField(),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   Container usernameTextField() {
//     return Container(
//                 width: 300,
//                 decoration: BoxDecoration(
//                   color: AppColors.white,
//                   borderRadius: BorderRadius.circular(25),
//                 ),
//                 child: Row(
//                   children: [
//                     Padding(
//                       padding: EdgeInsetsGeometry.only(left: 25),
//                       child: Icon(Icons.person_2_outlined),
//                     ),
//                     Expanded(
//                       child: Padding(
//                         padding: EdgeInsetsGeometry.only(top: 3,bottom: 3, left: 18),
//                         child: TextField(
//                           decoration: InputDecoration(
//                             hintText: "Enter Phone Number",
//                             helperStyle: TextStyle(color: AppColors.green),
//                             border: InputBorder.none,
//                           ),
//                         ),
//                       ),
//                     ),
//                     Padding(
//                       padding: EdgeInsetsGeometry.only(right: 15),
//                       child: Icon(
//                         Icons.check_circle,
//                         color: AppColors.green32,
//                       ),
//                     ),
//                   ],
//                 ),
//               );
//   }
// }
