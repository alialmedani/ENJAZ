

// ignore: constant_identifier_names
enum HttpMethod { GET, POST, PUT, DELETE }
