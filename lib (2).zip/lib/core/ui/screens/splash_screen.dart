import 'package:enjaz/core/utils/Navigation/navigation.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
 import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shimmer/shimmer.dart';
 import '../../classes/notification.dart';
import '../../constant/app_colors/app_colors.dart';
import '../../constant/app_images/app_images.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    initializeApp();
  }

  void initializeApp() async {
    try {
      // await context.read<ConfigrationCubit>().configApi();
      // await GetLocation().getLocation().timeout(
      //   const Duration(seconds: 10),
      //   onTimeout: () {
      //     if (kDebugMode) {
      //       print("Location request timed out");
      //     }
      //     return;
      //   },
      // );
      // await FireBaseNotification().initNotification();
    } catch (e) {
      if (kDebugMode) {
        print("Error initializing location: $e");
      }
    }

    // Navigation.pushAndRemoveUntil(const RootScreen());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SizedBox(
          width: 200.w,
          height: 200.h,
          child: Shimmer.fromColors(
            baseColor: AppColors.primary,
            highlightColor: AppColors.grey3B,
            child: Image.asset(logoPngImage),
          ),
        ),
      ),
    );
  }
}
